import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import MainMenu from './components/MainMenu';
import WeatherHome from './components/WeatherHome';
import Error404 from './components/Error404';

function App() {
  return (
    <Router>
      <div className="app-container bg-transparent">
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<MainMenu />} />
            <Route path="/weather" element={<WeatherHome />} />
            <Route path="*" element={<Error404 />} />
          </Routes>
        </AnimatePresence>
      </div>
    </Router>
  );
}

export default App;