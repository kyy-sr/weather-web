import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { WiDaySunny } from 'react-icons/wi';
import CurrentWeather from './CurrentWeather';
import Forecast from './Forecast';
import RainEffect from './RainEffect';

const API_KEY = 'c603dfe04626b70d084f4f8b7617d040'; // Ganti dengan API key OpenWeatherMap-mu
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

const WeatherHome = () => {
  const location = useLocation();
  const [city, setCity] = useState('Jakarta');
  const [currentWeather, setCurrentWeather] = useState(null);
  const [forecastData, setForecastData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [unit, setUnit] = useState('metric');
  const [unitSymbol, setUnitSymbol] = useState('°C');
  const [theme, setTheme] = useState('light');
  const [searchId, setSearchId] = useState(0);

  const getWeatherBackground = (weatherMain, theme) => {
    if (!weatherMain) {
      return theme === 'dark' 
        ? 'bg-gradient-to-br from-gray-800 to-gray-900 h-full'  // Ganti h-screen ke h-full untuk flex child
        : 'bg-gradient-to-br from-blue-400 to-blue-200 h-full';
    }
    const isDark = theme === 'dark';
    switch (weatherMain.toLowerCase()) {
      case 'clear':
        return isDark ? 'bg-gradient-to-br from-amber-800 to-orange-900 h-full' : 'bg-gradient-to-br from-yellow-400 to-orange-500 h-full';
      case 'clouds':
        return isDark ? 'bg-gradient-to-br from-gray-700 to-gray-900 h-full' : 'bg-gradient-to-br from-blue-400 to-gray-300 h-full';
      case 'rain':
      case 'drizzle':
        return isDark ? 'bg-gradient-to-br from-slate-800 to-gray-900 rainy-bg h-full' : 'bg-gradient-to-br from-gray-500 to-gray-700 rainy-bg h-full';
      case 'thunderstorm':
        return isDark ? 'bg-gradient-to-br from-purple-900 to-black h-full' : 'bg-gradient-to-br from-purple-600 to-gray-800 h-full';
      case 'snow':
        return isDark ? 'bg-gradient-to-br from-blue-900 to-gray-800 h-full' : 'bg-gradient-to-br from-blue-200 to-white h-full';
      case 'mist':
      case 'fog':
        return isDark ? 'bg-gradient-to-br from-gray-800 to-gray-600 h-full' : 'bg-gradient-to-br from-gray-300 to-gray-500 h-full';
      default:
        return isDark ? 'bg-gradient-to-br from-indigo-900 to-purple-900 h-full' : 'bg-gradient-to-br from-blue-400 to-purple-600 h-full';
    }
  };

  const fetchCurrentWeather = async (cityName, lat = null, lon = null) => {
    try {
      let url = `${BASE_URL}/weather?q=${cityName}&appid=${API_KEY}&units=${unit}`;
      if (lat && lon) url = `${BASE_URL}/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=${unit}`;
      const response = await axios.get(url);
      setCurrentWeather(response.data);
      setError('');
      if (!cityName && response.data.name) setCity(`${response.data.name}, ${response.data.sys.country}`);
    } catch (err) {
      setError('Kota tidak ditemukan atau error API. Coba lagi!');
    }
  };

  const fetchForecast = async (cityName, lat = null, lon = null) => {
    try {
      let url = `${BASE_URL}/forecast?q=${cityName}&appid=${API_KEY}&units=${unit}`;
      if (lat && lon) url = `${BASE_URL}/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=${unit}`;
      const response = await axios.get(url);
      const dailyForecast = response.data.list.filter((_, i) => i % 8 === 0).slice(0, 5);
      setForecastData(dailyForecast);
      setLoading(false);
    } catch (err) {
      setError('Error memuat forecast.');
      setLoading(false);
    }
  };

  const toggleUnit = () => {
    const newUnit = unit === 'metric' ? 'imperial' : 'metric';
    setUnit(newUnit);
    setUnitSymbol(newUnit === 'metric' ? '°C' : '°F');
    setSearchId(prev => prev + 1);
    setLoading(true);
  };

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    setSearchId(prev => prev + 1);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (city.trim()) {
      setSearchId(prev => prev + 1);
      setLoading(true);
      fetchCurrentWeather(city);
      fetchForecast(city);
    }
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      setSearchId(prev => prev + 1);
      setLoading(true);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          fetchCurrentWeather('', pos.coords.latitude, pos.coords.longitude);
          fetchForecast('', pos.coords.latitude, pos.coords.longitude);
        },
        () => {
          setError('Gagal mendapatkan lokasi. Gunakan search manual.');
          setLoading(false);
        }
      );
    } else {
      setError('Browser tidak support geolocation.');
    }
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    setTheme(savedTheme);
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    fetchCurrentWeather(city);
    fetchForecast(city);
  }, []);

  useEffect(() => {
    if (currentWeather) {
      setLoading(true);
      fetchCurrentWeather(city, currentWeather.coord.lat, currentWeather.coord.lon);
      fetchForecast(city, currentWeather.coord.lat, currentWeather.coord.lon);
    }
  }, [unit]);

  const animationKey = `search-${searchId}-${unit}-${theme}-${location.key}`;
  const weatherMain = currentWeather?.weather[0]?.main?.toLowerCase();

  return (
    <motion.div
      key="main-app"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className={`weather-home p-4 transition-all duration-500 flex flex-col ${getWeatherBackground(weatherMain, theme)}`}  // Tambah weather-home + flex flex-col + h-full di background func
      style={{ 
        position: 'relative', 
        zIndex: 1,
        minHeight: '100vh',  // Fallback inline CSS
        backgroundSize: 'cover'  // Pastikan gradient full
      }}
    >
      {/* Efek hujan partikel (hanya saat cuaca hujan) */}
      {weatherMain && ['rain', 'drizzle'].includes(weatherMain) && <RainEffect />}

      <div className="max-w-6xl mx-auto relative z-10 flex-grow">  
        <header className="text-center mb-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <h1 className={`text-4xl font-bold mb-2 transition-colors duration-300 ${
              theme === 'dark' ? 'text-white' : 'text-black'
            }`}>
              Weather App
            </h1>
            <p className={`transition-colors duration-300 ${
              theme === 'dark' ? 'text-white/80' : 'text-gray-600'
            }`}>
              Cek cuaca di mana saja!
            </p>
          </div>
          <motion.button
            onClick={toggleTheme}
            className={`px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-white text-gray-800 hover:bg-gray-100'
                : 'bg-white/20 text-black hover:bg-white/30'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            animate={{ rotate: theme === 'dark' ? 180 : 0 }}
          >
            {theme === 'dark' ? '☀️ Light' : '🌙 Dark'}
          </motion.button>
        </header>

        <form onSubmit={handleSearch} className="mb-6 flex flex-col sm:flex-row gap-2 justify-center">
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Masukkan nama kota (e.g., Jakarta)"
            className={`px-4 py-2 rounded-lg w-full sm:w-64 focus:outline-none focus:ring-2 transition-colors duration-300 ${
              theme === 'dark'
                ? 'bg-gray-700 text-white placeholder-gray-400 focus:ring-blue-400'
                : 'bg-white text-black placeholder-gray-500 focus:ring-blue-500'
            }`}
          />
          <button
            type="submit"
            className={`px-6 py-2 rounded-lg font-semibold hover:transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-white text-black hover:bg-gray-100'
            }`}
          >
            Search
          </button>
          <button
            type="button"
            onClick={getCurrentLocation}
            className={`px-6 py-2 rounded-lg font-semibold hover:transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-green-500 text-black hover:bg-green-600'
            }`}
          >
            My Location
          </button>
        </form>

        <div className="text-center mb-6">
          <button
            onClick={toggleUnit}
            className={`px-4 py-2 rounded-lg hover:transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-white/20 text-white hover:bg-white/30'
                : 'bg-white/20 text-black hover:bg-white/30'
            }`}
          >
            Switch to {unitSymbol === '°C' ? '°F' : '°C'}
          </button>
        </div>

        {error && (
          <div className={`p-4 rounded-lg text-center mb-6 animate-pulse transition-colors duration-300 ${
            theme === 'dark'
              ? 'bg-red-600/80 text-white'
              : 'bg-red-500 text-white'
          }`}>
            {error}
          </div>
        )}

        {loading && (
          <div className="flex justify-center flex-grow">  // Tambah flex-grow agar spinner isi ruang
            <div className={`animate-spin rounded-full h-12 w-12 border-b-2 transition-colors duration-300 ${
              theme === 'dark' ? 'border-white' : 'border-black'
            }`}></div>
          </div>
        )}

        <AnimatePresence mode="wait">
          {!loading && currentWeather && (
            <motion.div
              key={animationKey}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-grow"  // Tambah flex-grow
            >
              <CurrentWeather data={currentWeather} unitSymbol={unitSymbol} theme={theme} />
              <div className="lg:col-span-2">
                <Forecast data={forecastData} unitSymbol={unitSymbol} theme={theme} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Spacer bawah untuk force full jika konten pendek */}
      <div className="flex-shrink-0 h-0"></div> 
    </motion.div>
  );
};

export default WeatherHome;