import React from 'react';
import { motion } from 'framer-motion';
import { WiDaySunny, WiCloud, WiRain } from 'react-icons/wi';
import { useNavigate } from 'react-router-dom';

const MainMenu = () => {
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      transition={{ duration: 0.5 }}
      className="h-screen flex flex-col justify-center items-center bg-gradient-to-br from-blue-400 to-purple-600 text-white relative overflow-hidden"
    >
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="bg-white rounded-full opacity-20"
            style={{
              width: 6,
              height: 6,
              position: 'absolute',
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 3 + Math.random() * 2, delay: i * 0.1 }}
          />
        ))}
      </div>

      <motion.h1
        className="text-6xl font-extrabold mb-4 drop-shadow-lg flex items-center gap-4"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
      >
        Weather App
        <WiDaySunny className="text-yellow-400 animate-pulse" size={48} />
      </motion.h1>

      <motion.p
        className="mb-12 text-lg max-w-md text-center drop-shadow-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 0.85, y: 0 }}
        transition={{ delay: 0.5, duration: 0.6 }}
      >
        Dapatkan info cuaca akurat di seluruh dunia. Mulai perjalanan cuaca kamu sekarang!
      </motion.p>

      <motion.button
        onClick={() => navigate('/weather')}
        className="px-10 py-4 bg-white text-purple-700 font-semibold rounded-lg shadow-lg hover:shadow-2xl hover:bg-purple-100 transition-all duration-300"
        whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(139, 92, 246, 0.7)' }}
        whileTap={{ scale: 0.95 }}
      >
        Mulai Cek Cuaca
      </motion.button>

      <div className="flex gap-6 mt-16 text-white/70 text-5xl animate-bounce">
        <WiCloud />
        <WiRain />
        <WiDaySunny />
      </div>
    </motion.div>
  );
};

export default MainMenu;