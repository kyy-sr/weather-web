import React from 'react';
import { motion } from 'framer-motion';

const CurrentWeather = ({ data, unitSymbol, theme }) => {
  if (!data) return null;

  const { name, sys, main, weather, wind } = data;
  const countryCode = sys?.country || '';
  const weatherIcon = weather[0].icon;
  const iconUrl = `https://openweathermap.org/img/wn/${weatherIcon}@2x.png`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`p-6 rounded-xl shadow-lg backdrop-blur-sm transition-all duration-300 ${
        theme === 'dark'
          ? 'bg-white/10 text-white border border-white/20'
          : 'bg-white/80 text-black border border-gray-200/50'
      }`}
    >
      <div className="text-center">
        {/* Nama kota dan kode negara */}
        <h2 className={`text-3xl font-bold mb-2 transition-colors ${
          theme === 'dark' ? 'text-white' : 'text-black'
        }`}>
          {name}{countryCode ? `, ${countryCode}` : ''}
        </h2>

        {/* Ikon cuaca */}
        <img src={iconUrl} alt={weather[0].description} className="mx-auto w-24 h-24 mb-4" />

        {/* Deskripsi cuaca */}
        <p className={`text-lg mb-4 transition-colors ${
          theme === 'dark' ? 'text-white/90' : 'text-gray-700'
        }`}>
          {weather[0].description.toUpperCase()}
        </p>

        {/* Suhu saat ini */}
        <p className={`text-5xl font-bold mb-2 transition-colors ${
          theme === 'dark' ? 'text-white' : 'text-black'
        }`}>
          {Math.round(main.temp)} {unitSymbol}
        </p>

        {/* Suhu terasa seperti */}
        <p className={`text-sm transition-colors ${
          theme === 'dark' ? 'text-white/80' : 'text-gray-600'
        }`}>
          Feels like: {Math.round(main.feels_like)} {unitSymbol}
        </p>

        {/* Informasi tambahan: kelembapan dan kecepatan angin */}
        <div className="grid grid-cols-2 gap-4 mt-6 text-sm">
          <div className={`transition-colors ${
            theme === 'dark' ? 'text-white/80' : 'text-gray-700'
          }`}>
            <span>Humidity: {main.humidity}%</span>
          </div>
          <div className={`transition-colors ${
            theme === 'dark' ? 'text-white/80' : 'text-gray-700'
          }`}>
            <span>Wind: {wind.speed} m/s</span>
          </div>
          <div className={`transition-colors ${
            theme === 'dark' ? 'text-white/80' : 'text-gray-700'
          }`}>
            <span>Min: {Math.round(main.temp_min)} {unitSymbol}</span>
          </div>
          <div className={`transition-colors ${
            theme === 'dark' ? 'text-white/80' : 'text-gray-700'
          }`}>
            <span>Max: {Math.round(main.temp_max)} {unitSymbol}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default CurrentWeather;