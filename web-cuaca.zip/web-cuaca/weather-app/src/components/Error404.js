import React from 'react';
import { motion } from 'framer-motion';
import { WiRain, WiCloud } from 'react-icons/wi';
import { useNavigate } from 'react-router-dom';

const Error404 = () => {
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-br from-gray-400 to-gray-600 text-white relative overflow-hidden"
    >
      {/* Background awan bergerak */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="bg-white/20 rounded-full"
            style={{
              width: 100 + Math.random() * 200,
              height: 50 + Math.random() * 100,
              position: 'absolute',
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{ x: [0, -50, 0] }}
            transition={{ repeat: Infinity, duration: 10 + i * 2, ease: 'easeInOut' }}
          />
        ))}
      </div>

      {/* Konten utama */}
      <div className="text-center z-10 relative">
        <motion.div
          initial={{ scale: 0.5, rotate: -10 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-4"
        >
          <WiRain className="text-6xl text-blue-300 animate-bounce" />
          <WiCloud className="text-8xl text-gray-300 absolute -top-4 -right-4 animate-pulse" />
        </motion.div>

        <motion.h1
          className="text-6xl font-extrabold mb-4 drop-shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          404
        </motion.h1>

        <motion.p
          className="text-xl mb-8 max-w-md drop-shadow-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          Halaman yang kamu cari tidak ditemukan. Mungkin cuacanya lagi kabut? 🌫️
        </motion.p>

        {/* Tombol kembali */}
        <motion.button
          onClick={() => navigate('/weather')}
          className="px-8 py-3 bg-white text-gray-800 font-semibold rounded-lg shadow-lg hover:shadow-xl hover:bg-gray-100 transition-all duration-300"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
        >
          Kembali ke Weather App
        </motion.button>

        <motion.p
          className="mt-8 text-sm opacity-70"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 1 }}
        >
          Atau coba cek cuaca di kota favoritmu!
        </motion.p>
      </div>
    </motion.div>
  );
};

export default Error404;