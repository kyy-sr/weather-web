import React from 'react';
import { motion } from 'framer-motion';

const Forecast = ({ data, unitSymbol, theme }) => {
  if (!data || data.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, staggerChildren: 0.1 }}
      className={`p-6 rounded-xl shadow-lg backdrop-blur-sm transition-all duration-300 ${
        theme === 'dark'
          ? 'bg-white/10 text-white border border-white/20'
          : 'bg-white/80 text-black border border-gray-200/50'  // UPDATED: Teks hitam di light
      }`}
    >
      <h3 className={`text-2xl font-bold mb-4 transition-colors ${
        theme === 'dark' ? 'text-white' : 'text-black'  // UPDATED: Hitam murni untuk title
      }`}>
        5-Day Forecast
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {data.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            className={`p-4 rounded-lg text-center transition-all duration-300 ${
              theme === 'dark'
                ? 'bg-white/5 hover:bg-white/10'
                : 'bg-white/60 hover:bg-white/80'  // UPDATED: Light card
            }`}
          >
            {/* Date - UPDATED */}
            <p className={`font-semibold mb-2 transition-colors ${
              theme === 'dark' ? 'text-white' : 'text-black'  // UPDATED: Hitam di light
            }`}>
              {new Date(item.dt * 1000).toLocaleDateString('id-ID', { 
                weekday: 'short', 
                month: 'short', 
                day: 'numeric' 
              })}
            </p>
            
            {/* Icon */}
            <img 
              src={`https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png`} 
              alt={item.weather[0].description} 
              className="mx-auto w-12 h-12 mb-2" 
            />
            
            {/* Description - UPDATED */}
            <p className={`text-sm mb-2 transition-colors ${
              theme === 'dark' ? 'text-white/90' : 'text-gray-700'  // Subtext gray di light
            }`}>
              {item.weather[0].description}
            </p>
            
            {/* Temperature - UPDATED: Hitam di light */}
            <p className={`text-lg font-bold transition-colors ${
              theme === 'dark' ? 'text-white' : 'text-black'  // UPDATED: Hitam murni untuk suhu
            }`}>
              {Math.round(item.main.temp)} {unitSymbol}
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default Forecast;