// src/components/RainEffect.js
import React from 'react';

const RainEffect = () => {
  return (
    <div className="rain-container pointer-events-none fixed inset-0 z-0">
      {[...Array(100)].map((_, i) => (
        <div
          key={i}
          className="raindrop"
          style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 2}s`,
            animationDuration: `${0.5 + Math.random()}s`,
          }}
        />
      ))}
      <style jsx>{`
        .rain-container {
          position: fixed;
          top: 0; left: 0; right: 0; bottom: 0;
          pointer-events: none;
          z-index: 0;
        }
        .raindrop {
          position: absolute;
          top: -10px;
          width: 2px;
          height: 15px;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 50%;
          animation-name: fall;
          animation-timing-function: linear;
          animation-iteration-count: infinite;
        }
        @keyframes fall {
          0% { transform: translateY(0); opacity: 1; }
          100% { transform: translateY(100vh); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default RainEffect;